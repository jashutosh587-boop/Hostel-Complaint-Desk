# Online Hostel Complaint Management System

A simple web app where students report hostel problems and the warden tracks and resolves them.

## How to run (3 steps)
1. Install Python 3 from python.org (tick "Add Python to PATH").
2. Open a terminal in this folder and run:
       pip install -r requirements.txt
3. Start the app:
       python app.py
   Open http://127.0.0.1:5000 in your browser.

## Warden login
Username: warden    Password: admin123   (change both at the top of app.py)

## Files
- app.py              : all the logic (pages, database, login)
- templates/          : the HTML pages
- static/style.css    : the design
- complaints.db       : the database (created automatically on first run)

## Flow
Student submits form -> saved in database -> warden views list -> updates status -> student sees the update.
