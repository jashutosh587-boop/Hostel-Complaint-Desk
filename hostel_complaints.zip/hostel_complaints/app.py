# Online Hostel Complaint Management System
# Tools: Python (Flask) + SQLite + HTML/CSS
import sqlite3
from datetime import date
from functools import wraps
from flask import (Flask, render_template, request, redirect,
                   url_for, session, flash, g)

app = Flask(__name__)
app.secret_key = "change-this-secret-key"   # needed for login sessions

DATABASE = "complaints.db"
ADMIN_USER = "warden"        # change these before submitting
ADMIN_PASS = "admin123"

CATEGORIES = ["Water", "Food", "Electricity", "Cleaning", "Wi-Fi", "Other"]
STATUSES = ["Pending", "In Progress", "Resolved"]


# ---------- Database helpers ----------
def get_db():
    if "db" not in g:
        g.db = sqlite3.connect(DATABASE)
        g.db.row_factory = sqlite3.Row
    return g.db


@app.teardown_appcontext
def close_db(error):
    db = g.pop("db", None)
    if db is not None:
        db.close()


def init_db():
    """Create the one and only table if it does not exist."""
    db = sqlite3.connect(DATABASE)
    db.execute("""
        CREATE TABLE IF NOT EXISTS complaints (
            id           INTEGER PRIMARY KEY AUTOINCREMENT,
            student_name TEXT NOT NULL,
            room_no      TEXT NOT NULL,
            category     TEXT NOT NULL,
            description  TEXT NOT NULL,
            status       TEXT NOT NULL DEFAULT 'Pending',
            date         TEXT NOT NULL
        )
    """)
    db.commit()
    db.close()


def admin_required(view):
    @wraps(view)
    def wrapped(*args, **kwargs):
        if not session.get("admin"):
            flash("Please log in as warden first.", "error")
            return redirect(url_for("login"))
        return view(*args, **kwargs)
    return wrapped


# ---------- Student pages ----------
@app.route("/")
def home():
    return render_template("submit.html", categories=CATEGORIES)


@app.route("/submit", methods=["POST"])
def submit():
    name = request.form["student_name"].strip()
    room = request.form["room_no"].strip()
    category = request.form["category"]
    description = request.form["description"].strip()

    if not (name and room and description) or category not in CATEGORIES:
        flash("Please fill in all the fields.", "error")
        return redirect(url_for("home"))

    db = get_db()
    cur = db.execute(
        "INSERT INTO complaints (student_name, room_no, category, description, date) "
        "VALUES (?, ?, ?, ?, ?)",
        (name, room, category, description, date.today().isoformat()),
    )
    db.commit()
    flash(f"Complaint submitted. Your complaint number is #{cur.lastrowid}.", "success")
    return redirect(url_for("track", room_no=room))


@app.route("/track")
def track():
    room = request.args.get("room_no", "").strip()
    complaints = []
    if room:
        complaints = get_db().execute(
            "SELECT * FROM complaints WHERE room_no = ? ORDER BY id DESC", (room,)
        ).fetchall()
    return render_template("track.html", complaints=complaints, room=room)


# ---------- Warden (admin) pages ----------
@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        if (request.form["username"] == ADMIN_USER
                and request.form["password"] == ADMIN_PASS):
            session["admin"] = True
            return redirect(url_for("dashboard"))
        flash("Wrong username or password.", "error")
    return render_template("login.html")


@app.route("/logout")
def logout():
    session.pop("admin", None)
    return redirect(url_for("home"))


@app.route("/admin")
@admin_required
def dashboard():
    category = request.args.get("category", "")
    status = request.args.get("status", "")

    query = "SELECT * FROM complaints WHERE 1=1"
    params = []
    if category:
        query += " AND category = ?"
        params.append(category)
    if status:
        query += " AND status = ?"
        params.append(status)
    query += " ORDER BY id DESC"

    db = get_db()
    complaints = db.execute(query, params).fetchall()
    counts = {s: db.execute("SELECT COUNT(*) FROM complaints WHERE status = ?",
                            (s,)).fetchone()[0] for s in STATUSES}
    return render_template("dashboard.html", complaints=complaints, counts=counts,
                           categories=CATEGORIES, statuses=STATUSES,
                           sel_category=category, sel_status=status)


@app.route("/update/<int:complaint_id>", methods=["POST"])
@admin_required
def update(complaint_id):
    status = request.form["status"]
    if status in STATUSES:
        db = get_db()
        db.execute("UPDATE complaints SET status = ? WHERE id = ?",
                   (status, complaint_id))
        db.commit()
        flash(f"Complaint #{complaint_id} marked as {status}.", "success")
    return redirect(request.referrer or url_for("dashboard"))


@app.route("/delete/<int:complaint_id>", methods=["POST"])
@admin_required
def delete(complaint_id):
    db = get_db()
    db.execute("DELETE FROM complaints WHERE id = ?", (complaint_id,))
    db.commit()
    flash(f"Complaint #{complaint_id} deleted.", "success")
    return redirect(url_for("dashboard"))


if __name__ == "__main__":
    init_db()
    app.run(debug=True)
